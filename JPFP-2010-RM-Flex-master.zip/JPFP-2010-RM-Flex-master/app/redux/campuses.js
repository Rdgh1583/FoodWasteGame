import axios from "axios";

const SET_CAMPUSES = "SET_CAMPUSES";
const CREATE_CAMPUS = "CREATE_CAMPUS";
const DELETE_CAMPUS = "DELETE_CAMPUS";

export const _setCampuses = (campuses) => {
  return {
    type: SET_CAMPUSES,
    campuses,
  };
};

export const _fetchCampuses = (campus) => {
  return {
    type: CREATE_CAMPUS,
    campus,
  };
};

export const _deleteCampus = (id) => {
  return {
    type: DELETE_CAMPUS,
    id,
  };
};
//////

///////
export const fetchCampuses = () => {
  return async (dispatch) => {
    const campuses = (await axios.get("/api/campuses")).data;
    dispatch(_setCampuses(campuses));
  };
};

export const createCampus = (addCampus) => {
  return async (dispatch) => {
    const _addCampus = (await axios.post("/api/campuses", addCampus)).data;
    dispatch(_fetchCampuses(_addCampus));
  };
};

export const deleteCampus = (campus) => {
  return async (dispatch) => {
    const _campus = (await axios.delete(`/api/campuses/${campus}`)).data;
    dispatch(_deleteCampus(_campus));
  };
};

// Take a look at app/redux/index.js to see where this reducer is
// added to the Redux store with combineReducers
//////////////~Reducer~///////////////////
const initialState = [];

export default function campusesReducer(state = initialState, action) {
  if (action.type === SET_CAMPUSES) {
    state = action.campuses;
  }
  if (action.type === CREATE_CAMPUS) {
    state = [...state, action.campus];
  }
  if (action.type === DELETE_CAMPUS) {
    state = state.filter((campus) => {
      return campus.id !== action.campus.id;
    });
  }
  return state;
}
