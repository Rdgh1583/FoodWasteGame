import axios from "axios";

const CREATE_STUDENT = "CREATE_STUDENT";
const UPDATE_STUDENT = "UPDATE_STUDENT";
/////////////////////////~~Thunks~~/////////////////////////
export const _createStudent = (student) => {
  return {
    type: CREATE_STUDENT,
    student,
  };
};

export const _updateStudent = (student) => {
  return {
    type: UPDATE_STUDENT,
    student,
  };
};
//////////////////////////////////////////////////////
export const createStudent = (id) => {
  return async (dispatch) => {
    const student = (await axios.get(`/api/students/${id}`)).data;
    dispatch(_createStudent(student));
  };
};

export const updateStudent = (student) => {
  return async (dispatch) => {
    const newStudent = (await axios.put(`/api/students/${student.id}`, student))
      .data;
    dispatch(_updateStudent(newStudent));
  };
};

/////////////////////////~~Reducer~~/////////////////////////
const initialState = {};

export default function singleStudentReducer(state = initialState, action) {
  switch (action.type) {
    case CREATE_STUDENT:
      return action.student;
    case UPDATE_STUDENT:
      return {
        ...state,
        firstName: action.student.firstName,
        lastName: action.student.lastName,
        email: action.student.email,
      };
    default:
      return state;
  }
}
