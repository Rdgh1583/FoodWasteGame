import axios from "axios";

const SET_STUDENTS = "SET_STUDENTS";
const ADD_STUDENT = "ADD_STUDENT";
const DELETE_STUDENT = "DELETE_STUDENT";

/////////////////////////~~Thunks~~/////////////////////////
export const _setStudents = (students) => {
  return {
    type: SET_STUDENTS,
    students,
  };
};

export const _fetchStudents = (student) => {
  return {
    type: ADD_STUDENT,
    student,
  };
};

export const _deleteStudent = (student) => {
  return {
    type: DELETE_STUDENT,
    student,
  };
};
//////////////////////////////////////////////////////
export const setStudents = () => {
  return async (dispatch) => {
    const students = (await axios.get("/api/students")).data;
    dispatch(_setStudents(students));
  };
};
export const fetchStudents = (student) => {
  return async (dispatch) => {
    const _student = (await axios.post("/api/students", student)).data;
    dispatch(_fetchStudents(_student));
  };
};

export const deleteStudent = (id) => {
  return async (dispatch) => {
    await axios.delete("/api/students", { data: { id: id } });
    dispatch(_deleteStudent(id));
  };
};
//////////////////////////////////////////////////////
// Take a look at app/redux/index.js to see where this reducer is
// added to the Redux store with combineReducers
/////////////////////////~~Reducer~~/////////////////////////
const initialState = [];

export default function studentsReducer(state = initialState, action) {
  if (action.type === SET_STUDENTS) {
    state = action.students;
  }
  if (action.type === ADD_STUDENT) {
    state = [...state, action.student];
  }
  if (action.type === DELETE_STUDENT) {
    state = state.filter((student) => {
      return student.id !== action.student.id;
    });
  }
  return state;
}
