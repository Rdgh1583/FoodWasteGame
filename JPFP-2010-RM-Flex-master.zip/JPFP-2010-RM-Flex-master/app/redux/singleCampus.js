import axios from "axios";

const CREATE_CAMPUS = "CREATE_CAMPUS";
const UPDATE_CAMPUS = "UPDATE_CAMPUS";
const DESTROY = "DESTROY";

//////////////////////////////////////////////////////
export const _createCampus = (campus) => {
  return {
    type: CREATE_CAMPUS,
    campus,
  };
};

export const _updateCampus = (campus) => {
  return {
    type: UPDATE_CAMPUS,
    campus,
  };
};

export const _destroy = (campus) => {
  return {
    type: DESTROY,
    campus,
  };
};
//////////////////////////////////////////////////////
export const createCampus = (id) => {
  return async (dispatch) => {
    const campus = (await axios.get(`/api/campuses/${id}`)).data;
    dispatch(_createCampus(campus));
  };
};

export const updateCampus = (id) => {
  return async (dispatch) => {
    const campus = (await axios.put(`/api/campuses/${id}`)).data;
    dispatch(_updateCampus(campus));
  };
};
export const destroy = (id) => {
  return async (dispatch) => {
    const campus = (await axios.put(`/api/campuses/${id}`)).data;
    dispatch(_destroy(campus));
  };
};

/////////////////////////~~Reducer~~/////////////////////////
const initialState = {};

export default function singleCampusReducer(state = initialState, action) {
  switch (action.type) {
    case CREATE_CAMPUS:
      return { ...state, campus: action.campus };
    case UPDATE_CAMPUS:
      return { ...state, campus: action.campus };
    case DESTROY:
      return { ...state, campus: [action.campus, action.campus] };
    default:
      return state;
  }
}
