import React from "react";
import { BrowserRouter as Router } from "react-router-dom";
import AllCampuses from "./AllCampuses";
import AllStudents from "./AllStudents";
import SingleCampus from "./SingleCampus";
import SingleStudent from "./SingleStudent";

const Routes = () => {
  return (
    <Router>
      <div>
        <nav>
          Welcome, Techies!
          <Link to="/">Home</Link>
          <Link to="/campuses">Campuses</Link>
          <Link to="/students">Students</Link>
        </nav>
        <main>
          <h1>Welcome to the Margaret Hamilton Academy of JavaScript!</h1>
          {/* <p>This seems like a nice place to get started with some Routes!</p> */}
          <Route component={AllCampuses} exact path="/campuses" />
          <Route component={AllStudents} exact path="/students" />
          <Route component={SingleCampus} path="/campuses/:campusId" />
          <Route component={SingleStudent} path="/students/:studentId" />
        </main>
      </div>
    </Router>
  );
};

export default Routes;
