import React, { Component } from "react";
import { connect } from "react-redux";
import { setCampuses, fetchCampuses, deleteCampus } from "../redux/campuses";
import { Link } from "react-router-dom";

// Notice that we're exporting the AllCampuses component twice. The named export
// (below) is not connected to Redux, while the default export (at the very
// bottom) is connected to Redux. Our tests should cover _both_ cases.
export class AllCampuses extends Component {
  componentDidMount() {
    this.props.getCampuses();
  }

  render() {
    return (
      <div>
        {this.props.campuses.map((campus) => {
          return (
            <div>
              {campus.name}
              <img src={campus.imageUrl} />
            </div>
          );
        })}
      </div>
    );
  }
}

const mapState = (state) => {
  return state;
};

const mapDispatch = (dispatch) => {
  return {
    getCampuses: () => dispatch(fetchCampuses()),
  };
};

export default connect(mapState, mapDispatch)(AllCampuses);
