import React, { Component } from "react";
import { connect } from "react-redux";
import { createStudent } from "../redux/singleStudent";

class CreateStudent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName: "",
      lastName: "",
      email: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  handleSubmit(event) {
    event.preventDefault();
    this.props.create(this.state.name, this.state.address);
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <div>
          <label htmlFor="first_name">First Name</label>
          <input
            name="first_name"
            placeholder="Enter First Name"
            value={this.state.firstName}
            onChange={this.handleChange}
          />
        </div>
        <div>
          <label htmlFor="last_name">Last Name</label>
          <input
            name="last_name"
            placeholder="Enter Last Name"
            value={this.state.lastName}
            onChange={this.handleChange}
          />
        </div>
        <div>
          <label htmlFor="email">e-mail</label>
          <input
            name="email"
            placeholder="Enter e-mail"
            value={this.state.email}
            onChange={this.handleChange}
          />
        </div>
        <div>
          <button>Add Student</button>
        </div>
      </form>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    student: state.student,
  };
};

export default connect(mapStateToProps, (dispatch, { history }) => {
  return {
    createStudent: (firstName, lastName, email) =>
      dispatch(createStudent(firstName, lastName, email)),
  };
})(CreateStudent);
