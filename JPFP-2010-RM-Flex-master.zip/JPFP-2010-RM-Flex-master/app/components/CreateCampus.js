import React, { Component } from "react";
import { connect } from "react-redux";
import { createCampus } from "../redux/campuses";

class CreateCampus extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      address: "",
      imageUrl: "",
      description: "",
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }
  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  handleSubmit(event) {
    event.preventDefault();
    this.props.create(this.state.name, this.state.address);
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <div>
          <label htmlFor="name">Name</label>
          <input
            name="name"
            placeholder="Enter Campus Name"
            value={this.state.name}
            onChange={this.handleChange}
          />
        </div>
        <div>
          <label htmlFor="address">Address</label>
          <input
            name="address"
            placeholder="Enter Campus Address"
            value={this.state.address}
            onChange={this.handleChange}
          />
        </div>
        <div>
          <button>Submit</button>
        </div>
      </form>
    );
  }
}
const mapStateToProps = (state) => {
  return {
    campus: state.campus,
  };
};

export default connect(mapStateToProps, (dispatch, { history }) => {
  return {
    createCampus: (name, address) =>
      dispatch(createCampus(name, address, history)),
  };
})(CreateCampus);
