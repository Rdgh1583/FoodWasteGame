import React, { Component } from "react";
import { connect } from "react-redux";
import { editCampus } from "../redux/campuses";

class EditCampus extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "" || this.props.campus.name,
      address: "" || this.props.campus.address,
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  handleSubmit(event) {
    event.preventDefault();
    const campus = {
      ...this.state,
    };
    this.props.editCampus(campus);
  }

  render() {
    const { name, address } = this.state;
    const { handleSubmit, handleChange } = this;
    return (
      <form id="campus-form" onSubmit={handleSubmit}>
        <label htmlFor="name">Campus Name</label>
        <input name="name" onChange={handleChange} value={name} />

        <label htmlFor="address">Address</label>
        <input name="address" onChange={handleChange} value={address} />
        <button type="submit">Submit</button>
      </form>
    );
  }
}
const mapState = ({ campus }) => {
  return { campus };
};

const mapDispatch = (dispatch, { history }) => {
  return {
    editCampus: (campus) => dispatch(editCampus(campus, history)),
  };
};
export default connect(mapState, mapDispatch)(EditCampus);
