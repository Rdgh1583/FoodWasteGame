import React from "react";
import { connect } from "react-redux";
import { editStudent } from "../redux/singleStudent";
////////////////////////////////////
class EditStudent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName: "" || this.props.student.firstName,
      lastName: "" || this.props.student.lastName,
      email: "" || this.props.student.email,
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  componentDidUpdate(prevProps) {
    console.log(this.props);
    if (this.props.student.id && !prevProps.student.id) {
      this.setState({
        firstName: this.props.student.firstName,
        lastName: this.props.student.lastName,
        email: this.props.student.email,
      });
    }
  }

  handleChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  handleSubmit(event) {
    event.preventDefault();
    const campus = {
      ...this.state,
    };
    this.props.editCampus(campus);
  }

  render() {
    const { firstName, lastName, email } = this.state;
    const { handleSubmit, handleChange } = this;
    return (
      <form id="update-student-form" onSubmit={handleSubmit}>
        <label htmlFor="firstName">First Name:</label>
        <input name="firstName" onChange={handleChange} value={firstName} />

        <label htmlFor="lastName">Last Name:</label>
        <input name="lastName" onChange={handleChange} value={lastName} />

        <label htmlFor="email">Email:</label>
        <input name="email" onChange={handleChange} value={email} />

        <button type="submit">Submit</button>
      </form>
    );
  }
}
////////////////////////////////////
const mapState = ({ student }) => {
  return { student };
};

const mapDispatch = (dispatch) => {
  return {
    editStudent: (student) => dispatch(editStudent(student)),
  };
};

export default connect(mapState, mapDispatch)(EditStudent);
