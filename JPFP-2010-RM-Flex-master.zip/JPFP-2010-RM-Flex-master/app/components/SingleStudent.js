import React, { Component } from "react";
import { connect } from "react-redux";
import { createStudent } from "../redux/singleStudent";
import { Link } from "react-router-dom";
import EditStudent from "./EditStudent";
class SingleStudent extends Component {
  componentDidMount() {
    this.props.getSingleStudent(this.props.match.params.id);
  }

  render() {
    const student = this.props.student;
    return (
      <div>
        <div id="student_info_single">
          <p>Student Info:</p>
          <p>{`Name: ${student.firstName} ${student.lastName}`}</p>
          <p>{`Email: ${student.email} `}</p>
          <img src={student.imageUrl} />
          <p>{`GPA: ${student.gpa} `}</p>
          {student.campus ? (
            <Link to={`/campuses/${student.campus.id}`}>
              <p>{`Campus: ${student.campus.name}`}</p>
            </Link>
          ) : (
            <p>Campus: None</p>
          )}
        </div>
        <EditStudent />
      </div>
    );
  }
}
export default connect(
  ({ student }) => {
    return { student: student };
  },
  (dispatch) => {
    return {
      createStudent: (id) => dispatch(createStudent(id)),
    };
  }
)(SingleStudent);
