import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import { createCampus, destroy } from "../redux/singleCampus";
import EditCampus from "./EditCampus";

class SingleCampus extends Component {
  constructor(props) {
    super(props);
    this.onClick = this.onClick.bind(this);
  }
  componentDidMount() {
    this.props.getSingleCampus(this.props.match.campusId);
  }
  onClick(event) {
    this.props.unregisterStudent({
      campusId: this.props.match.params.id,
      studentId: event.target.name,
    });
  }
  render() {
    const campus = this.props.campus;
    return (
      <div>
        <div>
          <p>Campus Information</p>
          <p>{`Name: ${campus.name} `}</p>
          <p>{`Address: ${campus.address} `}</p>
          <img src={campus.imageUrl} />
          <p>{`Description: ${campus.description} `}</p>
        </div>
        {campus.students ? (
          <div>
            Student Roster:
            <ul>
              {campus.students.length === 0 ? "No students" : ""}
              {campus.students.map((student, index) => {
                return (
                  <li id="campus_student_link" key={index}>
                    <Link to={`/students/${student.id}`}>
                      {`${student.firstName} ${student.lastName}`}
                    </Link>
                    <button
                      id={`button_${index}`}
                      name={student.id}
                      onClick={(event) => this.onClick(event)}
                    >
                      X
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ) : (
          <div>...Loading </div>
        )}
        <EditCampus />
      </div>
    );
  }
}

export default connect(
  ({ campus }) => {
    return { campus: campus };
  },
  (dispatch) => {
    return {
      createCampus: (id) => dispatch(createCampus(id)),
      destroy: (id) => dispatch(destroy(id)),
    };
  }
)(SingleCampus);
