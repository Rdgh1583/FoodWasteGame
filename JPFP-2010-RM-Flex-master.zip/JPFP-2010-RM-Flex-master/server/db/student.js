const database = require("./database");
const { STRING, FLOAT } = require("sequelize");

const Student = database.define("student", {
  firstName: {
    type: STRING,
    allowNull: false,
    validate: {
      notEmpty: true,
    },
  },
  lastName: {
    type: STRING,
    allowNull: false,
    validate: {
      notEmpty: true,
    },
  },
  email: {
    type: STRING,
    allowNull: false,
    validate: {
      notEmpty: true,
      isEmail: true,
    },
  },
  imageUrl: {
    type: STRING,
    defaultValue: "nyt.com",
  },
  gpa: {
    type: FLOAT,
    validate: {
      min: 0.0,
      max: 4.0,
    },
  },
});

module.exports = Student;
