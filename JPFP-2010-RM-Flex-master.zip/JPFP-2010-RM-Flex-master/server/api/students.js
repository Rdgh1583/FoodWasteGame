const router = require("express").Router();
const { Student, Campus } = require("../db");

router.get("/", async (req, res, next) => {
  try {
    const students = await Student.findAll();
    res.send(students);
  } catch (er) {
    console.log(er);
    next(er);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const student = await Student.create({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      email: req.body.email,
    });
    res.status(201).send(student);
  } catch (er) {
    console.log(er);
    next(er);
  }
});

router.delete("/", async (req, res, next) => {
  try {
    await Student.destroy({
      where: {
        id: req.body.id,
      },
    });
    res.sendStatus(204);
  } catch (er) {
    console.log(er);
    next(er);
  }
});

router.get("/:id", async (req, res, next) => {
  try {
    const individualStudent = await Student.findByPk(req.params.id, {
      include: Campus,
    });
    res.send(individualStudent);
  } catch (er) {
    console.log(er);
    next(er);
  }
});
router.put("/:studentId", async (req, res, next) => {
  try {
    const student = await Student.findOne({
      where: {
        id: req.params.studentId,
      },
      include: Campus,
    });
    res.send(await student.update(req.body));
  } catch (er) {
    next(er);
  }
});

module.exports = router;
