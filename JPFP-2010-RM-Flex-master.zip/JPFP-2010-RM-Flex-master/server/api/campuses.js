const router = require("express").Router();
const { Campus, Student } = require("../db");

router.get("/", async (req, res, next) => {
  try {
    const campuses = await Campus.findAll();
    res.send(campuses);
  } catch (er) {
    next(er);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const campus = await Campus.create({
      name: req.body.name,
      address: req.body.address,
    });
    res.status(201).send(campus);
  } catch (er) {
    console.log(er);
    next(er);
  }
});

router.delete("/", async (req, res, next) => {
  try {
    await Campus.destroy({
      where: {
        id: req.body.id,
      },
    });
    res.sendStatus(204);
  } catch (er) {
    console.log(er);
    next(er);
  }
});
///////////////////////////////////
router.get("/:id", async (req, res, next) => {
  try {
    const singleCampus = await Campus.findByPk(req.params.id, {
      include: Student,
    });
    res.send(singleCampus);
  } catch (er) {
    console.log(er);
    next(er);
  }
});

router.put("/unregister", async (req, res, next) => {
  try {
    await Student.update(
      {
        campusId: null,
      },
      {
        where: {
          id: req.body.studentId,
        },
      }
    );
    res.send(201).end();
  } catch (er) {
    console.log(er);
    next(er);
  }
});

module.exports = router;
